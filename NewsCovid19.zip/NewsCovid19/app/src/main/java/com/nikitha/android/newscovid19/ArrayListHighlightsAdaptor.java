package com.nikitha.android.newscovid19;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class ArrayListHighlightsAdaptor extends ArrayAdapter<ListItems> {
    ListItems currentword;
    ArrayList<ListItems> listItemsArray=new ArrayList<>();

    public ArrayListHighlightsAdaptor(@NonNull Context context, @NonNull ArrayList<ListItems> objects) {
        super(context, 0, objects);
        listItemsArray=objects;
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(R.layout.list_items_layout, parent, false);
        }
        final String[] parts = (parent.toString()).split("app:id/", 2);
        currentword = getItem(position);

        ImageView imageView1= listItemView.findViewById(R.id.image1);
        imageView1.setImageBitmap(currentword.getImage());

        TextView textViewtitle= listItemView.findViewById(R.id.title1);
        textViewtitle.setText(currentword.getTitle());

        TextView textViewsource= listItemView.findViewById(R.id.source1);
        textViewsource.setText(currentword.getSource());

        return listItemView;
    }

    public void setData(ArrayList<ListItems> data) {
        listItemsArray.addAll(data);
        notifyDataSetChanged();
    }
}
