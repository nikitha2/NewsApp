package com.nikitha.android.newscovid19;

public class CONSTANTS {

    static int HTTP_OK_CONNECTION=200;
}
