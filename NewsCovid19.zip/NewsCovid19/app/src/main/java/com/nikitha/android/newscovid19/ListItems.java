package com.nikitha.android.newscovid19;

import android.graphics.Bitmap;

public class ListItems {

    Bitmap image;
    String title;
    String source;
    String url;

    public ListItems(Bitmap image, String title, String source, String url) {
        this.image = image;
        this.title = title;
        this.source = source;
        this.url = url;
    }

    public Bitmap getImage() {
        return image;
    }

    public void setImage(Bitmap image) {
        this.image = image;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
