package com.nikitha.android.newscovid19;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.Loader;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<ArrayList<ListItems>> {
    ArrayList<ListItems> populatedData=new ArrayList<ListItems>();
    ArrayListHighlightsAdaptor  arrayListHighlightsAdaptor;
    Bundle input=new Bundle();
    String url1="https://newsapi.org/v2/top-headlines?q=coronavirus&apiKey=77d76053f2604ce1bb4a7bc30944dcf5";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //populatedData= populatData(populatedData);

        ListView listView=findViewById(R.id.listView1);
        arrayListHighlightsAdaptor=new ArrayListHighlightsAdaptor(this,populatedData);
        listView.setAdapter(arrayListHighlightsAdaptor);

        LayoutInflater inflater = getLayoutInflater();
        View headerView = getLayoutInflater().inflate(R.layout.header, null);
        listView.addHeaderView(headerView);

        input.putString("url",url1);
        LoaderManager.getInstance(this).initLoader(1, input, this).forceLoad();
    }

    private ArrayList<ListItems> populatData(List<ListItems> populatedData) {
        Bitmap image=null;

        for(int i=0;i<10;i++) {
            populatedData.add(new ListItems(image, "title", "source", "url"));
        }
        return (ArrayList<ListItems>) populatedData;
    }

    @NonNull
    @Override
    public Loader<ArrayList<ListItems>> onCreateLoader(int id, @Nullable Bundle args) {
        return new HighlightsLoader(this,args);
    }

    @Override
    public void onLoadFinished(@NonNull Loader<ArrayList<ListItems>> loader, ArrayList<ListItems> data) {
        try{
            if(data!=null && data.size()>0) {
                arrayListHighlightsAdaptor.setData(data);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public void onLoaderReset(@NonNull Loader<ArrayList<ListItems>> loader) {

    }
}
